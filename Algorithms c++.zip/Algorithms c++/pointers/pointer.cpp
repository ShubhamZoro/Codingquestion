#include<iostream>
using namespace std;
void increment(int *a){
    cout<<*a<<endl;
    *a=*a+1;
}
int main(){
// int a=10;
// int *ptr=&a;
// cout<<a<<endl;
// cout<<&a<<endl;
// //before increasing ptr
// cout<<ptr<<endl;
// cout<<*ptr<<endl;
// a++;
// cout<<ptr<<endl;
// cout<<*ptr<<endl;
// //after increasing ptr
// ptr++;
// cout<<ptr<<endl;
// cout<<*ptr<<endl;
int arr[]={10,20,30};
cout<<arr<<endl;
cout<<&arr[0]<<endl;
cout<<*arr<<endl;
int *ptr=arr;
for(int i=0;i<3;i++){
    cout<<*ptr<<endl;
    ptr++;

}
cout<<endl;
for(int i=0;i<3;i++){
    cout<<*(arr+i)<<endl;
    //arr++ -> illegal;
}

cout<<endl;
cout<<"Pointer to pointer"<<endl;
int k=2;
increment(&k);
cout<<k<<endl;

}
