#include<iostream>
using namespace std;
int exponentiaton(int n,int p)
{

    if(p==0)
        return 1;
    return n*exponentiaton(n,p-1);

}
int main()
{
    cout<<exponentiaton(5,3);
}
