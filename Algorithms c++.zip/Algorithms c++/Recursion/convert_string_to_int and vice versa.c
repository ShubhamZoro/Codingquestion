#include<iostream>
#include<string>
using namespace std;
int main()
{
    int n=1234;
    string s=to_string(n);
    cout<<s;
}
