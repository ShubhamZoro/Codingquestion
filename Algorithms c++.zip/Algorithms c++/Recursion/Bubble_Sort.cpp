#include<iostream>
#include<algorithm>
using namespace std;

void bubble_sort(int a[],int n)
{

    if(n==1){
        return ;
    }
    for(int i=0;i<n-1;i++){
        if(a[i]>a[i+1]){
            swap(a[i],a[i+1]);
        }
    }
    bubble_sort(a,n-1);
}
void bubble_sort_rec_2(int a[],int n,int j){
if(n==1){
    return ;
}
if(j==n-1){
    bubble_sort_rec_2(a,n-1,0);
    return;
}
if(a[j]>a[j+1]){
    swap(a[j],a[j+1]);
}
bubble_sort_rec_2(a,n,j+1);
}
int main(){
int arr[5]={57,41,98,2,1};
bubble_sort_rec_2(arr,5,0);
for(int i=0;i<5;i++){
    cout<<arr[i]<<" ";
}
}
