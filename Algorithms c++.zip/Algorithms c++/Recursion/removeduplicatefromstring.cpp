#include <iostream>
#include<string>
using namespace std;

string remove_duplicates(string words)
{
    if(words.length()==0)
        return "";
    char ch=words[0];
    string ans=remove_duplicates(words.substr(1));
    if(ch==ans[0])
        return ans;
    return ch+ans;
}

int main()
{

    cout<<remove_duplicates("aaabbbccccdddeeee");

}
