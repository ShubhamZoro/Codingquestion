#include<stdio.h>
int main()
{
   printf("%p",main);
   getchar();
   return 0;
}
