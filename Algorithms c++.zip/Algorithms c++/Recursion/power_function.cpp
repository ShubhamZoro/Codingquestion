#include<iostream>
using namespace std;

int power_function(int n,int pow){
if( pow==0){
    return 1;
}
return n*power_function(n,pow-1);


}

int main(){
int x=power_function(5,4);
cout<<x;
}
