#include<iostream>
using namespace std;
void reverse_string(string A)
{   if(A.size()==0)
        return;

    string ros=A.substr(1);

    reverse_string(ros);
    cout<<ros[0];




}
int main()
{

    reverse_string("binod");
    return 0;
}
