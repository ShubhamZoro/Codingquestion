#include<iostream>
using namespace std;
string spell[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
void number_spell(int n)
{
    if(n==0){
        return ;
    }
    int r=n%10;
    number_spell(n/10);
    cout<<spell[r];

}
int main(){
    int n;
    cin>>n;
    number_spell(n);
    return 0;
}
