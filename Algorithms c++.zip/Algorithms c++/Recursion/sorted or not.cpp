#include<iostream>
using namespace std;
bool sorted(int arr[],int i,int n)
{
    if(i==n-1)
    {   cout<< "s";
         return true;
    }


    if(arr[i]>arr[i+1])
        return false;
    return sorted(arr,i+1,n);
}
bool sorted1(int arr[],int n)
{
    if(n==1)
    {   cout<< "s";
         return true;
    }


    if(arr[0]>arr[1])
        return false;
    return sorted1(arr+1,n-1);
}
int main()
{
    int arr[]={1,4,5,16,17};
    cout<<sorted1(arr,5);
}
