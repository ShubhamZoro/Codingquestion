#include<iostream>
using namespace std;
void repalce_pi( string s)
{
    if(s.length()==0)
    {
        return ;
    }
   if(s[0]=='p' && s[1]=='i')
   {
       cout<<"3.14";
       repalce_pi(s.substr(2));
   }
   else
   {
       cout<<s[0];
       repalce_pi(s.substr(1));
   }




}
int main()
{
        string s="pippxxppiixipi";
        repalce_pi(s);
}
