#include<iostream>
using namespace std;

class Queue{
int *arr;
int cs;
int ms;
int Front;
int rear;

public:
    Queue(int default_size=5)
    {

        ms=default_size;
        arr=new int[ms];
        cs=0;
        Front=0;
        rear=ms-1;
    }
    void push(int data)
    {
        if(cs!=ms){
            rear=(rear+1)%ms;
            arr[rear]=data;
            cs++;
        }
    }
    void pop()
    {
        if(cs!=0)
        {
            Front=(Front+1)%ms;
            cs--;
        }
        else{
            cout<< "Queue is empty";
        }
    }
    int getFront()
    {
        return arr[rear];
    }
};
int main()
{
    Queue q(7);
    q.push(1);
    q.push(2);
    q.push(4);
    q.push(6);
    cout<< q.getFront()<<endl;
    q.pop();
    q.push(4);
    cout<< q.getFront();
    return 0;
}
