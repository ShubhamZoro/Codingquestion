#include<iostream>
using namespace std;

int **create2DArray(int rows,int cols){
int **arr=new int*[rows];
for(int i=0;i<rows;i++){
    arr[i]=new int[cols];
}
int value=0;
for(int i=0;i<rows;i++){
    for(int j=0;j<cols;j++){
        arr[i][j]=value;
        value++;
    }
}
return arr;
}

int main(){
int n;
cin>>n;
int *arr=new int[n];
for(int i=0;i<n;i++){
    arr[i]=i;
    cout<<arr[i]<< " ";
}
cout<<endl;
delete [] arr;
//cout<< arr<< endl;
//cout<<arr[2]<<endl;
//2D Dynamic Arrray
int rows,cols;
cin>>rows>>cols;
int **arr1=create2DArray(rows,cols);
for(int i=0;i<rows;i++){
    for(int j=0;j<cols;j++){
        cout<<arr1[i][j]<<endl;

    }
}
}
