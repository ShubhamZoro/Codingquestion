// The number of visitor on the day is strictly larger than the number of visitors on each of the previous days.
// Either it is the last day, or the number of visitor on the day is strictly larger than the number of visitors on the following days.
#include<iostream>
using namespace std;
int main()
{
    int arr[]={1,0,4,5,3,7};
    int n=sizeof(arr)/sizeof(arr[0]);
    int result=0;
    int mx=-1;
    for(int i=0;i<n;i++)
    {
        if(arr[i]>mx&&arr[i]>arr[i+1])
        {
            result++;
        }
        mx=max(mx,arr[i]);
    }
    cout<<result;
}
