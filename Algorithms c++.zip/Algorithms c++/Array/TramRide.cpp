#include<bits/stdc++.h>
using namespace std;

long long solve (int N, int start, int finish, vector<int> Ticket_cost) {
   // Write your code here
   if (start == finish)
        return 0;

    // Calculate cost in the clockwise direction
    int tmp = start - 1;
    long long int sum = 0;
    while (tmp != finish - 1) {
        sum += Ticket_cost[tmp];
        tmp = (tmp + 1) % Ticket_cost.size();
    }

    // Calculate cost in the anti-clockwise direction
    tmp = (finish - 1) % Ticket_cost.size();
    long long int sum2 = 0;
    while (tmp != (start - 1)) {
        sum2 += Ticket_cost[tmp];
        tmp = (tmp + 1) % Ticket_cost.size();
    }

    // Return the minimum cost between clockwise and anti-clockwise directions
    return min(sum, sum2);

}

int main() {

    ios::sync_with_stdio(0);
    cin.tie(0);
    int N;
    cin >> N;
    int start;
    cin >> start;
    int finish;
    cin >> finish;
    vector<int> Ticket_cost(N);
    for(int i_Ticket_cost = 0; i_Ticket_cost < N; i_Ticket_cost++)
    {
    	cin >> Ticket_cost[i_Ticket_cost];
    }

    long long out_;
    out_ = solve(N, start, finish, Ticket_cost);
    cout << out_;
}
