#include<iostream>
using namespace std;
int main()
{
    int arr[]={1,3,5,7,9,11,13,15,12,15,16,17,18,19,20,21,22,23,24,25};
    int n=0;
    int count1=1;
    int diff=arr[0]-arr[1];
    for(int i=1;i<sizeof(arr)/sizeof(arr[0])-1;i++)
    {
        int curr=arr[i]-arr[i+1];
        if(diff==curr)
        {
            count1++;
        }
        else{
            count1=1;
            diff=curr;
        }
        if(count1>n)
        {
            n=count1;
        }
    }
    cout<<n+1;
}
