#include<iostream>
#include<vector>
using namespace std;
int main(){
     int sum=-100000;
     int nums[]={-2,1,-3,4,-1,2,1,-5,4};
          int p=sizeof(nums)/sizeof(nums[0]);
        int prefix[p]={0};

     prefix[0]=nums[0];
    for(int i=1;i<p;i++){
        prefix[i]=prefix[i-1]+nums[i];
    }
    for(int i=0;i<p;i++){
        for(int j=i;j<p;j++)
        {
            int max1=i>0?prefix[j]-prefix[i-1] : prefix[j];
            if (max1>sum){
                sum=max1;
            }


        }

    }
       cout<< sum;

}
