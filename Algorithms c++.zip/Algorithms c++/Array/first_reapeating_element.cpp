//Task is to find the first repeating element in array.
#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    int arr[]={2,3,3,4,3,1,6,7,5,4,0};
    int n=sizeof(arr)/sizeof(arr[0]);
    int m= *max_element(arr, arr + n);
    int idx[m+1];
    for(int i=0;i<m+1;i++)
        idx[i]=-1;
    int min_idx=INT_MAX;
    for(int i=0;i<n;i++)
    {
        int k=arr[i];

        if(idx[k]!=-1&&min_idx>idx[k])
        {
            min_idx=idx[k];
        }
        idx[k]=i;
    }
    cout<<min_idx;
}
