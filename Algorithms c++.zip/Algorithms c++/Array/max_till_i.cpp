#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    int arr[]={12,13,45,67,89,14,23,89};
    int max1=4;
    int n=sizeof(arr)/sizeof(arr[0]);
    int p=INT_MIN;
    for(int i=0;i<n;i++)
    {
        p=max(p,arr[i]);

    }
    cout<<p;
}
