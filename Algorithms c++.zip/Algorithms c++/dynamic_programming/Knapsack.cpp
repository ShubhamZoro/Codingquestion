#include<iostream>
#include<vector>
using namespace std;

int recurknapsack(int wts[],int price[],int N,int w){
if(N==0||w==0){
    return 0;
}
int inc=0,exc=0;
if(wts[N-1]<=w){
    inc=price[N-1]+recurknapsack(wts,price,N-1,w-wts[N-1]);
}
exc=recurknapsack(wts,price,N-1,w);
return max(inc,exc);
}

int knapsack(int wts[],int price[],int N,int w){
vector<vector<int>>dp(N+1,vector<int>(w+1,0));
for(int i=1;i<=N;i++){
    for(int j=1;j<=w;j++){
        if(wts[i-1]<=j){
            dp[i][j]=max(dp[i-1][j],price[i-1]+dp[i-1][j-wts[i-1]]);
        }
        else{
            dp[i][j]=dp[i-1][j];
        }
    }
}
return dp[N][w];
}

int main(){
    int N=4,w=11;
int wts[N]={2,7,3,4};
int prices[N]={5,20,20,10};
cout<<knapsack(wts,prices,N,w);

}
