#include<iostream>
#include <typeinfo>

using namespace std;

int main(){
int var =8;
cout<<&var<<endl;
int *ptr=&var;
cout<<*ptr<<"\n";
cout<<ptr<<"\n";
cout<<&ptr<<"\n";
var=var+2;
cout<<*ptr<<"\n";
cout<<ptr<<"\n";
cout<<var<<endl;


int **prev=&ptr;
cout << *prev<< endl;
cout << prev<< endl;
cout << **prev<< endl;
cout << *(&ptr)<< endl;
cout << **(&ptr)<< endl;
}
